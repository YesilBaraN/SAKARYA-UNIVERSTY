﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace veritabanıproje
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123");
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();  // Bağlantıyı açıyoruz

                    string sorgu = "SELECT * FROM urun";
                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                    DataSet ds = new DataSet();
                    da.Fill(ds);  // Verileri DataSet'e dolduruyoruz
                    dataGridView1.DataSource = ds.Tables[0];  // DataGridView'e veriyi bağlıyoruz

                    MessageBox.Show("Veriler başarıyla listelendi.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    // Veriyi eklemek için SQL komutunu hazırlıyoruz
                    baglanti.Open();  // Bağlantıyı açıyoruz
                    NpgsqlCommand komut = new NpgsqlCommand("INSERT INTO urun (kategoriid, eklenmetarihi, urunadi, birimfiyat, stokmiktari) VALUES (@p1, @p2, @p3, @p4, @p5)", baglanti);

                    // Parametreler ekleniyor (kullanıcıdan alınan veriler)
                    komut.Parameters.AddWithValue("@p1", int.Parse(txtKategoriID.Text));
                    komut.Parameters.AddWithValue("@p2", DateTime.Parse(txtEklenmeTarihi.Text));
                    komut.Parameters.AddWithValue("@p3", txtUrunAdi.Text);
                    komut.Parameters.AddWithValue("@p4", decimal.Parse(txtBirimFiyat.Text));
                    komut.Parameters.AddWithValue("@p5", int.Parse(txtStokMiktari.Text));

                    // Sorgu çalıştırılıyor
                    komut.ExecuteNonQuery();  // Veriyi ekliyoruz

                    // Kullanıcıya işlem başarılı mesajı gösteriliyor
                    MessageBox.Show("Ürün kaydı başarılı");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    int urunID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["UrunID"].Value);

                    using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                    {
                        baglanti.Open();  // Bağlantıyı açıyoruz

                        NpgsqlCommand komut = new NpgsqlCommand("DELETE FROM urun WHERE urunid=@p1", baglanti);
                        komut.Parameters.AddWithValue("@p1", urunID);

                        komut.ExecuteNonQuery();  // Veriyi siliyoruz

                        MessageBox.Show("Seçili ürün başarıyla silindi.");
                    }

                    // Listeyi güncelliyoruz (Veritabanındaki veriler yeniden çekilir)
                    button4_Click(sender, e);
                }
                else
                {
                    MessageBox.Show("Lütfen silmek istediğiniz satırı seçin.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı açıyoruz
                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();  // Veritabanına bağlantı açılıyor

                    // Güncelleme için SQL komutunu yazıyoruz (UrunID ile veriyi bulup güncelliyoruz)
                    string sorgu = "UPDATE urun SET kategoriid=@p1, eklenmetarihi=@p2, urunadi=@p3, birimfiyat=@p4, stokmiktari=@p5 WHERE urunid=@p6";

                    NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti);

                    // Parametreleri ekliyoruz
                    komut.Parameters.AddWithValue("@p1", int.Parse(txtKategoriID.Text));
                    komut.Parameters.AddWithValue("@p2", DateTime.Parse(txtEklenmeTarihi.Text));
                    komut.Parameters.AddWithValue("@p3", txtUrunAdi.Text);
                    komut.Parameters.AddWithValue("@p4", decimal.Parse(txtBirimFiyat.Text));
                    komut.Parameters.AddWithValue("@p5", int.Parse(txtStokMiktari.Text));
                    komut.Parameters.AddWithValue("@p6", int.Parse(txtUrunID.Text)); // Güncellenecek UrunID

                    // Komutu çalıştırıyoruz
                    komut.ExecuteNonQuery();

                    // İşlem başarılı mesajı gösteriyoruz
                    MessageBox.Show("Ürün başarıyla güncellendi");
                }
            }
            catch (Exception ex)
            {
                // Hata oluşursa mesaj kutusunda gösteriyoruz
                MessageBox.Show("Hata: " + ex.Message);
            }
        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Debug amaçlı MessageBox ile seçili hücreyi kontrol et
                MessageBox.Show("Seçili Ürün ID: " + row.Cells["UrunID"].Value.ToString());

                // Veriyi TextBox'lara aktarma
                txtUrunID.Text = row.Cells["UrunID"].Value.ToString();
                txtKategoriID.Text = row.Cells["KategoriID"].Value.ToString();
                txtEklenmeTarihi.Text = row.Cells["EklenmeTarihi"].Value.ToString();
                txtUrunAdi.Text = row.Cells["UrunAdi"].Value.ToString();
                txtBirimFiyat.Text = row.Cells["BirimFiyat"].Value.ToString();
                txtStokMiktari.Text = row.Cells["StokMiktari"].Value.ToString();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                // Kullanıcıdan alınan UrunID'yi alıyoruz
                int urunIDArama = int.Parse(txtUrunIDArama.Text); // Burada TextBox'tan alınan ürün ID'sini parse ediyoruz

                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();  // Bağlantıyı açıyoruz

                    // Ürün ID'sine göre sorguyu yazıyoruz
                    string sorgu = "SELECT * FROM urun WHERE urunid = @p1";
                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                    da.SelectCommand.Parameters.AddWithValue("@p1", urunIDArama);  // Parametre ekliyoruz
                    DataSet ds = new DataSet();
                    da.Fill(ds);  // Veriyi DataSet'e dolduruyoruz

                    // Eğer arama sonucunda veri varsa, DataGridView'e yazdırıyoruz
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        dataGridView1.DataSource = ds.Tables[0];  // Sadece eşleşen veriyi gösteriyoruz
                        MessageBox.Show("Arama başarılı, ürün bulundu.");
                    }
                    else
                    {
                        MessageBox.Show("Ürün ID'si ile eşleşen veri bulunamadı.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }
    }
}
