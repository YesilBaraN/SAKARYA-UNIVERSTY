﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace veritabanıproje
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Seçili satırdaki verileri TextBox'lara aktarıyoruz
                txtIslemID.Text = row.Cells["IslemID"].Value.ToString();
                txtIslemTarihi.Text = row.Cells["IslemTarih"].Value.ToString();
                txtIslemTipi.Text = row.Cells["IslemTipi"].Value.ToString();
                txtAciklama.Text = row.Cells["Aciklama"].Value.ToString();
                txtUrunID.Text = row.Cells["UrunID"].Value.ToString();
                txtKullaniciID.Text = row.Cells["KullaniciID"].Value.ToString();
            }
        }

        private void Ekle_Click(object sender, EventArgs e)
        {
            try
            {
                // Veritabanına bağlantıyı açıyoruz
                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();  // Bağlantıyı açıyoruz

                    // SQL INSERT sorgusunu yazıyoruz (Yeni işlem kaydını eklemek için)
                    string sorgu = "INSERT INTO IslemKaydi (IslemTarih, IslemTipi, Aciklama, UrunID, KullaniciID) VALUES (@p1, @p2, @p3, @p4, @p5)";

                    NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti);

                    // Parametreleri ekliyoruz (TextBox'lardan alınan veriler)
                    komut.Parameters.AddWithValue("@p1", DateTime.Parse(txtIslemTarihi.Text));  // IslemTarih
                    komut.Parameters.AddWithValue("@p2", txtIslemTipi.Text);  // IslemTipi
                    komut.Parameters.AddWithValue("@p3", txtAciklama.Text);  // Aciklama
                    komut.Parameters.AddWithValue("@p4", int.Parse(txtUrunID.Text));  // UrunID
                    komut.Parameters.AddWithValue("@p5", int.Parse(txtKullaniciID.Text));  // KullaniciID

                    // Sorguyu çalıştırıyoruz
                    komut.ExecuteNonQuery();

                    // İşlem başarılı mesajı gösteriyoruz
                    MessageBox.Show("İşlem kaydı başarıyla eklendi");
                }
            }
            catch (Exception ex)
            {
                // Hata oluşursa mesaj kutusunda gösteriyoruz
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void Güncelle_Click(object sender, EventArgs e)
        {

            try
            {
                // IslemID mevcutsa güncelleme işlemi yapılır
                if (txtIslemID.Text != "")
                {
                    // Veritabanına bağlantıyı açıyoruz
                    using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                    {
                        baglanti.Open();  // Bağlantıyı açıyoruz

                        // SQL UPDATE sorgusunu yazıyoruz (IslemID'ye göre güncelleme)
                        string sorgu = "UPDATE IslemKaydi SET IslemTarih=@p1, IslemTipi=@p2, Aciklama=@p3, UrunID=@p4, KullaniciID=@p5 WHERE IslemID=@p6";

                        NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti);

                        // Parametreleri ekliyoruz (TextBox'lardan alınan veriler)
                        komut.Parameters.AddWithValue("@p1", DateTime.Parse(txtIslemTarihi.Text));  // IslemTarih
                        komut.Parameters.AddWithValue("@p2", txtIslemTipi.Text);  // IslemTipi
                        komut.Parameters.AddWithValue("@p3", txtAciklama.Text);  // Aciklama
                        komut.Parameters.AddWithValue("@p4", int.Parse(txtUrunID.Text));  // UrunID
                        komut.Parameters.AddWithValue("@p5", int.Parse(txtKullaniciID.Text));  // KullaniciID
                        komut.Parameters.AddWithValue("@p6", int.Parse(txtIslemID.Text));  // Güncellenecek IslemID

                        // Sorguyu çalıştırıyoruz
                        komut.ExecuteNonQuery();

                        // İşlem başarılı mesajı gösteriyoruz
                        MessageBox.Show("İşlem kaydı başarıyla güncellendi");
                    }

                    // Listeyi güncelliyoruz (DataGridView'i tekrar dolduruyoruz)
                    Listele_Click(sender, e);
                }
                else
                {
                    // IslemID'yi girilmediğinde kullanıcıyı uyarıyoruz
                    MessageBox.Show("Lütfen güncellemek istediğiniz işlem kaydını seçin.");
                }
            }
            catch (Exception ex)
            {
                // Hata oluşursa mesaj kutusunda gösteriyoruz
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void Sil_Click(object sender, EventArgs e)
        {
            try
            {
                // Seçili satır var mı kontrol ediyoruz
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    // Seçili satırdaki IslemID'yi alıyoruz
                    int islemID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["IslemID"].Value);

                    // Veritabanına bağlantıyı açıyoruz
                    using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                    {
                        baglanti.Open();  // Bağlantıyı açıyoruz

                        // SQL DELETE sorgusunu yazıyoruz (IslemID'ye göre silme)
                        string sorgu = "DELETE FROM IslemKaydi WHERE IslemID=@p1";

                        NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti);
                        komut.Parameters.AddWithValue("@p1", islemID);  // Parametre olarak IslemID'yi ekliyoruz

                        // Komut çalıştırılıyor
                        komut.ExecuteNonQuery();

                        // İşlem başarılı mesajı gösteriyoruz
                        MessageBox.Show("İşlem kaydı başarıyla silindi");
                    }

                    // Listeyi güncelliyoruz (DataGridView'i tekrar dolduruyoruz)
                    Listele_Click(sender, e);
                }
                else
                {
                    // Satır seçilmediğinde kullanıcıyı uyarıyoruz
                    MessageBox.Show("Lütfen silmek istediğiniz satırı seçin.");
                }
            }
            catch (Exception ex)
            {
                // Hata oluşursa mesaj kutusunda gösteriyoruz
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void Listele_Click(object sender, EventArgs e)
        {

            try
            {
                // Veritabanına bağlantıyı açıyoruz
                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();  // Bağlantıyı açıyoruz

                    // SQL SELECT sorgusunu yazıyoruz (Tüm işlem kayıtlarını çekiyoruz)
                    string sorgu = "SELECT * FROM IslemKaydi";

                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                    DataSet ds = new DataSet();
                    da.Fill(ds);  // Veriyi DataSet'e dolduruyoruz

                    // DataGridView'e veriyi bağlıyoruz
                    dataGridView1.DataSource = ds.Tables[0];

                    // Bağlantıyı kapatıyoruz
                    baglanti.Close();
                }
            }
            catch (Exception ex)
            {
                // Hata oluşursa mesaj kutusunda gösteriyoruz
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void xtKullaniciID_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIslemID_TextChanged(object sender, EventArgs e)
        {

        }

        private void Arama_Click(object sender, EventArgs e)
        {
            try
            {
                // Kullanıcıdan alınan IslemID'yi alıyoruz
                int islemIDArama = int.Parse(txtIslemIDArama.Text); // TextBox'tan alınan işlem ID'sini parse ediyoruz

                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();  // Bağlantıyı açıyoruz

                    // IslemID'ye göre sorguyu yazıyoruz
                    string sorgu = "SELECT * FROM IslemKaydi WHERE IslemID = @p1";
                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                    da.SelectCommand.Parameters.AddWithValue("@p1", islemIDArama);  // Parametre olarak IslemID'yi ekliyoruz
                    DataSet ds = new DataSet();
                    da.Fill(ds);  // Veriyi DataSet'e dolduruyoruz

                    // Eğer arama sonucunda veri varsa, DataGridView'e yazdırıyoruz
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        dataGridView1.DataSource = ds.Tables[0];  // Sadece eşleşen veriyi gösteriyoruz
                        MessageBox.Show("Arama başarılı, işlem kaydı bulundu.");
                    }
                    else
                    {
                        MessageBox.Show("IslemID ile eşleşen işlem kaydı bulunamadı.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }
    }
}
