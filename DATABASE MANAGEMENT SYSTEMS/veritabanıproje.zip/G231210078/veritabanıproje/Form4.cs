﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace veritabanıproje
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        private string baglantiString = "server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123";

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                txtKategoriID.Text = row.Cells["KategoriID"].Value.ToString();
                txtKategoriAdi.Text = row.Cells["KategoriAdi"].Value.ToString();
                txtAciklama.Text = row.Cells["Aciklama"].Value.ToString();
                txtRenk.Text = row.Cells["Renk"].Value.ToString();
            }
        }

        private void Ekle_Click(object sender, EventArgs e)
        {

            using (NpgsqlConnection baglanti = new NpgsqlConnection(baglantiString))
            {
                baglanti.Open();
                string sorgu = "INSERT INTO Kategori (KategoriAdi, Aciklama, Renk) VALUES (@p1, @p2, @p3)";
                NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti);
                komut.Parameters.AddWithValue("@p1", txtKategoriAdi.Text);
                komut.Parameters.AddWithValue("@p2", txtAciklama.Text);
                komut.Parameters.AddWithValue("@p3", txtRenk.Text);
                komut.ExecuteNonQuery();
                MessageBox.Show("Kategori başarıyla eklendi.");
                Listele_Click(sender, e);
            }
        }

        private void Listele_Click(object sender, EventArgs e)
        {

            using (NpgsqlConnection baglanti = new NpgsqlConnection(baglantiString))
            {
                baglanti.Open();
                string sorgu = "SELECT * FROM Kategori";
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void Sil_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtKategoriID.Text))
            {
                MessageBox.Show("Silmek için bir Kategori ID girin!");
                return;
            }

            using (NpgsqlConnection baglanti = new NpgsqlConnection(baglantiString))
            {
                baglanti.Open();
                string sorgu = "DELETE FROM Kategori WHERE KategoriID = @p1";
                NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti);
                komut.Parameters.AddWithValue("@p1", int.Parse(txtKategoriID.Text));
                komut.ExecuteNonQuery();
                MessageBox.Show("Kategori başarıyla silindi.");
                Listele_Click(sender, e);
            }
        }

        private void Güncelle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtKategoriID.Text))
            {
                MessageBox.Show("Güncellemek için bir Kategori ID girin!");
                return;
            }

            using (NpgsqlConnection baglanti = new NpgsqlConnection(baglantiString))
            {
                baglanti.Open();
                string sorgu = "UPDATE Kategori SET KategoriAdi = @p1, Aciklama = @p2, Renk = @p3 WHERE KategoriID = @p4";
                NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti);
                komut.Parameters.AddWithValue("@p1", txtKategoriAdi.Text);
                komut.Parameters.AddWithValue("@p2", txtAciklama.Text);
                komut.Parameters.AddWithValue("@p3", txtRenk.Text);
                komut.Parameters.AddWithValue("@p4", int.Parse(txtKategoriID.Text));
                komut.ExecuteNonQuery();
                MessageBox.Show("Kategori başarıyla güncellendi.");
                Listele_Click(sender, e);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Kullanıcıdan alınan KategoriID'yi alıyoruz
                int kategoriIDArama = int.Parse(txtKategoriIDArama.Text); // TextBox'tan alınan kategori ID'sini parse ediyoruz

                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();  // Bağlantıyı açıyoruz

                    // KategoriID'ye göre sorguyu yazıyoruz
                    string sorgu = "SELECT * FROM Kategori WHERE KategoriID = @p1";
                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                    da.SelectCommand.Parameters.AddWithValue("@p1", kategoriIDArama);  // Parametre olarak KategoriID'yi ekliyoruz
                    DataSet ds = new DataSet();
                    da.Fill(ds);  // Veriyi DataSet'e dolduruyoruz

                    // Eğer arama sonucunda veri varsa, DataGridView'e yazdırıyoruz
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        dataGridView1.DataSource = ds.Tables[0];  // Sadece eşleşen veriyi gösteriyoruz
                        MessageBox.Show("Arama başarılı, kategori kaydı bulundu.");
                    }
                    else
                    {
                        MessageBox.Show("KategoriID ile eşleşen kategori kaydı bulunamadı.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }
    }
}
