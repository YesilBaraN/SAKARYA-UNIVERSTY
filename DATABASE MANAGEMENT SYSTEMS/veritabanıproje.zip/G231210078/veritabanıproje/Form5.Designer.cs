﻿namespace veritabanıproje
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.DepoID = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Miktar = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUrunDepoID = new System.Windows.Forms.TextBox();
            this.txtDepoID = new System.Windows.Forms.TextBox();
            this.txtUrunID = new System.Windows.Forms.TextBox();
            this.txtMiktar = new System.Windows.Forms.TextBox();
            this.txtSonGuncelleme = new System.Windows.Forms.TextBox();
            this.Ekle = new System.Windows.Forms.Button();
            this.Güncelle = new System.Windows.Forms.Button();
            this.Sil = new System.Windows.Forms.Button();
            this.Listele = new System.Windows.Forms.Button();
            this.txtUrunDepoIDArama = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(-1, -7);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(739, 455);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(796, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "UrunDepoID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // DepoID
            // 
            this.DepoID.AutoSize = true;
            this.DepoID.Location = new System.Drawing.Point(796, 63);
            this.DepoID.Name = "DepoID";
            this.DepoID.Size = new System.Drawing.Size(54, 16);
            this.DepoID.TabIndex = 3;
            this.DepoID.Text = "DepoID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(796, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "UrunID";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // Miktar
            // 
            this.Miktar.AutoSize = true;
            this.Miktar.Location = new System.Drawing.Point(796, 122);
            this.Miktar.Name = "Miktar";
            this.Miktar.Size = new System.Drawing.Size(43, 16);
            this.Miktar.TabIndex = 5;
            this.Miktar.Text = "Miktar";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(796, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "SonGuncelleme";
            // 
            // txtUrunDepoID
            // 
            this.txtUrunDepoID.Location = new System.Drawing.Point(954, 24);
            this.txtUrunDepoID.Name = "txtUrunDepoID";
            this.txtUrunDepoID.Size = new System.Drawing.Size(100, 22);
            this.txtUrunDepoID.TabIndex = 7;
            // 
            // txtDepoID
            // 
            this.txtDepoID.Location = new System.Drawing.Point(954, 57);
            this.txtDepoID.Name = "txtDepoID";
            this.txtDepoID.Size = new System.Drawing.Size(100, 22);
            this.txtDepoID.TabIndex = 8;
            // 
            // txtUrunID
            // 
            this.txtUrunID.Location = new System.Drawing.Point(954, 90);
            this.txtUrunID.Name = "txtUrunID";
            this.txtUrunID.Size = new System.Drawing.Size(100, 22);
            this.txtUrunID.TabIndex = 9;
            // 
            // txtMiktar
            // 
            this.txtMiktar.Location = new System.Drawing.Point(954, 122);
            this.txtMiktar.Name = "txtMiktar";
            this.txtMiktar.Size = new System.Drawing.Size(100, 22);
            this.txtMiktar.TabIndex = 10;
            // 
            // txtSonGuncelleme
            // 
            this.txtSonGuncelleme.Location = new System.Drawing.Point(954, 150);
            this.txtSonGuncelleme.Name = "txtSonGuncelleme";
            this.txtSonGuncelleme.Size = new System.Drawing.Size(100, 22);
            this.txtSonGuncelleme.TabIndex = 11;
            // 
            // Ekle
            // 
            this.Ekle.Location = new System.Drawing.Point(799, 205);
            this.Ekle.Name = "Ekle";
            this.Ekle.Size = new System.Drawing.Size(75, 23);
            this.Ekle.TabIndex = 12;
            this.Ekle.Text = "Ekle";
            this.Ekle.UseVisualStyleBackColor = true;
            this.Ekle.Click += new System.EventHandler(this.Ekle_Click);
            // 
            // Güncelle
            // 
            this.Güncelle.Location = new System.Drawing.Point(1019, 205);
            this.Güncelle.Name = "Güncelle";
            this.Güncelle.Size = new System.Drawing.Size(75, 23);
            this.Güncelle.TabIndex = 13;
            this.Güncelle.Text = "Güncelle";
            this.Güncelle.UseVisualStyleBackColor = true;
            this.Güncelle.Click += new System.EventHandler(this.Güncelle_Click);
            // 
            // Sil
            // 
            this.Sil.Location = new System.Drawing.Point(904, 205);
            this.Sil.Name = "Sil";
            this.Sil.Size = new System.Drawing.Size(75, 23);
            this.Sil.TabIndex = 14;
            this.Sil.Text = "Sil";
            this.Sil.UseVisualStyleBackColor = true;
            this.Sil.Click += new System.EventHandler(this.Sil_Click);
            // 
            // Listele
            // 
            this.Listele.Location = new System.Drawing.Point(904, 284);
            this.Listele.Name = "Listele";
            this.Listele.Size = new System.Drawing.Size(75, 23);
            this.Listele.TabIndex = 15;
            this.Listele.Text = "Listele";
            this.Listele.UseVisualStyleBackColor = true;
            this.Listele.Click += new System.EventHandler(this.Listele_Click);
            // 
            // txtUrunDepoIDArama
            // 
            this.txtUrunDepoIDArama.Location = new System.Drawing.Point(831, 371);
            this.txtUrunDepoIDArama.Name = "txtUrunDepoIDArama";
            this.txtUrunDepoIDArama.Size = new System.Drawing.Size(92, 22);
            this.txtUrunDepoIDArama.TabIndex = 16;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(958, 367);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 26);
            this.button1.TabIndex = 17;
            this.button1.Text = "Arama";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1123, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtUrunDepoIDArama);
            this.Controls.Add(this.Listele);
            this.Controls.Add(this.Sil);
            this.Controls.Add(this.Güncelle);
            this.Controls.Add(this.Ekle);
            this.Controls.Add(this.txtSonGuncelleme);
            this.Controls.Add(this.txtMiktar);
            this.Controls.Add(this.txtUrunID);
            this.Controls.Add(this.txtDepoID);
            this.Controls.Add(this.txtUrunDepoID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Miktar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.DepoID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label DepoID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Miktar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtUrunDepoID;
        private System.Windows.Forms.TextBox txtDepoID;
        private System.Windows.Forms.TextBox txtUrunID;
        private System.Windows.Forms.TextBox txtMiktar;
        private System.Windows.Forms.TextBox txtSonGuncelleme;
        private System.Windows.Forms.Button Ekle;
        private System.Windows.Forms.Button Güncelle;
        private System.Windows.Forms.Button Sil;
        private System.Windows.Forms.Button Listele;
        private System.Windows.Forms.TextBox txtUrunDepoIDArama;
        private System.Windows.Forms.Button button1;
    }
}