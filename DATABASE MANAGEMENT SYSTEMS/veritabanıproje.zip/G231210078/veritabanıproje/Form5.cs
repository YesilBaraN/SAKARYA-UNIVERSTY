﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace veritabanıproje
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123");

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Ekle_Click(object sender, EventArgs e)
        {
            try
            {
                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();
                    string sorgu = "INSERT INTO UrunDepo (DepoID, UrunID, Miktar, SonGuncelleme) VALUES (@p1, @p2, @p3, @p4)";
                    using (NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti))
                    {
                        komut.Parameters.AddWithValue("@p1", int.Parse(txtDepoID.Text));
                        komut.Parameters.AddWithValue("@p2", int.Parse(txtUrunID.Text));
                        komut.Parameters.AddWithValue("@p3", int.Parse(txtMiktar.Text));
                        komut.Parameters.AddWithValue("@p4", DateTime.Parse(txtSonGuncelleme.Text));
                        komut.ExecuteNonQuery();
                    }
                    MessageBox.Show("Kayıt başarıyla eklendi.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void Sil_Click(object sender, EventArgs e)
        {
            try
            {
                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();
                    string sorgu = "DELETE FROM UrunDepo WHERE UrunDepoID = @p1";
                    using (NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti))
                    {
                        komut.Parameters.AddWithValue("@p1", int.Parse(txtUrunDepoID.Text));
                        komut.ExecuteNonQuery();
                    }
                    MessageBox.Show("Kayıt başarıyla silindi.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void Güncelle_Click(object sender, EventArgs e)
        {
            try
            {
                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();
                    string sorgu = "UPDATE UrunDepo SET DepoID = @p1, UrunID = @p2, Miktar = @p3, SonGuncelleme = @p4 WHERE UrunDepoID = @p5";
                    using (NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti))
                    {
                        komut.Parameters.AddWithValue("@p1", int.Parse(txtDepoID.Text));
                        komut.Parameters.AddWithValue("@p2", int.Parse(txtUrunID.Text));
                        komut.Parameters.AddWithValue("@p3", int.Parse(txtMiktar.Text));
                        komut.Parameters.AddWithValue("@p4", DateTime.Parse(txtSonGuncelleme.Text));
                        komut.Parameters.AddWithValue("@p5", int.Parse(txtUrunDepoID.Text));
                        komut.ExecuteNonQuery();
                    }
                    MessageBox.Show("Kayıt başarıyla güncellendi.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void Listele_Click(object sender, EventArgs e)
        {
            try
            {
                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();
                    string sorgu = "SELECT * FROM UrunDepo";
                    using (NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                txtUrunDepoID.Text = row.Cells["UrunDepoID"].Value.ToString();
                txtDepoID.Text = row.Cells["DepoID"].Value.ToString();
                txtUrunID.Text = row.Cells["UrunID"].Value.ToString();
                txtMiktar.Text = row.Cells["Miktar"].Value.ToString();
                txtSonGuncelleme.Text = row.Cells["SonGuncelleme"].Value.ToString();
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Kullanıcıdan alınan UrunDepoID'yi alıyoruz
                int urunDepoIDArama = int.Parse(txtUrunDepoIDArama.Text); // TextBox'tan alınan UrunDepoID'yi parse ediyoruz

                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();  // Bağlantıyı açıyoruz

                    // UrunDepoID'ye göre sorguyu yazıyoruz
                    string sorgu = "SELECT * FROM UrunDepo WHERE UrunDepoID = @p1";
                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                    da.SelectCommand.Parameters.AddWithValue("@p1", urunDepoIDArama);  // Parametre olarak UrunDepoID'yi ekliyoruz
                    DataSet ds = new DataSet();
                    da.Fill(ds);  // Veriyi DataSet'e dolduruyoruz

                    // Eğer arama sonucunda veri varsa, DataGridView'e yazdırıyoruz
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        dataGridView1.DataSource = ds.Tables[0];  // Sadece eşleşen veriyi gösteriyoruz
                        MessageBox.Show("Arama başarılı, depo kaydı bulundu.");
                    }
                    else
                    {
                        MessageBox.Show("UrunDepoID ile eşleşen depo kaydı bulunamadı.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }
    }
}
