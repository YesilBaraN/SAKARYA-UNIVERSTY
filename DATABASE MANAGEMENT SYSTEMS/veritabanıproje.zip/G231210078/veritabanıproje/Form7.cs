﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace veritabanıproje
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123");

        private void Listele_Click(object sender, EventArgs e)
        {

            try
            {
                // Bağlantıyı açıyoruz
                baglanti.Open();

                // Verileri çekmek için SQL komutunu yazıyoruz
                string sorgu = "SELECT * FROM UrunGorusleri";
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);

                // Verileri DataTable'a çekiyoruz
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Verileri DataGridView'e bağlıyoruz
                dataGridView1.DataSource = dt;

                // Bağlantıyı kapatıyoruz
                baglanti.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
