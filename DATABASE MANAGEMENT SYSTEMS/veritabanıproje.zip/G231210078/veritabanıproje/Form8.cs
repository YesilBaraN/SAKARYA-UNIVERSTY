﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace veritabanıproje
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        // Bağlantı nesnesi
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123");
        // Ekleme işlemi
        private void Eklle()
        {
            try
            {
                // Sipariş ID, Urun ID, Miktar ve BirimFiyat gibi değerleri TextBox'lardan alıyoruz
                int siparisID = int.Parse(txtSiparisID.Text);
                int urunID = int.Parse(txtUrunID.Text);
                int miktar = int.Parse(txtMiktar.Text);
                decimal birimFiyat = decimal.Parse(txtBirimFiyat.Text);
                decimal tutar = miktar * birimFiyat;  // Tutarı hesaplıyoruz

                baglanti.Open(); // Bağlantıyı açıyoruz

                // SiparişUrun tablosuna veri ekliyoruz
                string sorgu = "INSERT INTO SiparisUrun (SiparisID, UrunID, Miktar, BirimFiyat, Tutar) VALUES (@siparisID, @urunID, @miktar, @birimFiyat, @tutar)";
                NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti);

                komut.Parameters.AddWithValue("@siparisID", siparisID);
                komut.Parameters.AddWithValue("@urunID", urunID);
                komut.Parameters.AddWithValue("@miktar", miktar);
                komut.Parameters.AddWithValue("@birimFiyat", birimFiyat);
                komut.Parameters.AddWithValue("@tutar", tutar);

                komut.ExecuteNonQuery(); // Veriyi ekliyoruz

                MessageBox.Show("Sipariş ürünü başarıyla eklendi.");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.Close(); // Bağlantıyı kapatıyoruz
            }
        }

        // Silme işlemi
        private void Sill()
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    int siparisUrunID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["SiparisUrunID"].Value);

                    baglanti.Open(); // Bağlantıyı açıyoruz

                    string sorgu = "DELETE FROM SiparisUrun WHERE SiparisUrunID = @siparisUrunID";
                    NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti);

                    komut.Parameters.AddWithValue("@siparisUrunID", siparisUrunID);

                    komut.ExecuteNonQuery(); // Veriyi siliyoruz

                    MessageBox.Show("Sipariş ürünü başarıyla silindi.");

                    // Listeyi güncelle
                    Listelle();
                }
                else
                {
                    MessageBox.Show("Lütfen silmek istediğiniz satırı seçin.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.Close(); // Bağlantıyı kapatıyoruz
            }
        }

        // Güncelleme işlemi
        private void Güncellle()
        {
            try
            {
                int siparisUrunID = int.Parse(txtSiparisUrunID.Text); // Güncellenecek SiparisUrunID
                int siparisID = int.Parse(txtSiparisID.Text);
                int urunID = int.Parse(txtUrunID.Text);
                int miktar = int.Parse(txtMiktar.Text);
                decimal birimFiyat = decimal.Parse(txtBirimFiyat.Text);
                decimal tutar = miktar * birimFiyat; // Tutarı yeniden hesaplıyoruz

                baglanti.Open(); // Bağlantıyı açıyoruz

                string sorgu = "UPDATE SiparisUrun SET SiparisID = @siparisID, UrunID = @urunID, Miktar = @miktar, BirimFiyat = @birimFiyat, Tutar = @tutar WHERE SiparisUrunID = @siparisUrunID";
                NpgsqlCommand komut = new NpgsqlCommand(sorgu, baglanti);

                komut.Parameters.AddWithValue("@siparisID", siparisID);
                komut.Parameters.AddWithValue("@urunID", urunID);
                komut.Parameters.AddWithValue("@miktar", miktar);
                komut.Parameters.AddWithValue("@birimFiyat", birimFiyat);
                komut.Parameters.AddWithValue("@tutar", tutar);
                komut.Parameters.AddWithValue("@siparisUrunID", siparisUrunID);

                komut.ExecuteNonQuery(); // Veriyi güncelliyoruz

                MessageBox.Show("Sipariş ürünü başarıyla güncellendi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.Close(); // Bağlantıyı kapatıyoruz
            }
        }

        // Listeleme işlemi
        private void Listelle()
        {
            try
            {
                baglanti.Open(); // Bağlantıyı açıyoruz

                string sorgu = "SELECT * FROM SiparisUrun"; // Veritabanındaki tüm SiparisUrun verilerini çekiyoruz
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                DataSet ds = new DataSet();
                da.Fill(ds); // Verileri DataSet'e dolduruyoruz

                dataGridView1.DataSource = ds.Tables[0]; // DataGridView'e veriyi bağlıyoruz

                MessageBox.Show("Veriler başarıyla listelendi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.Close(); // Bağlantıyı kapatıyoruz
            }
        }
        private void Form8_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //ekle butonu

            Eklle(); // Ekle metodu çalıştırılır
        }

        private void Sil_Click(object sender, EventArgs e)
        {
            Sill(); // Sil metodu çalıştırılır
        }

        private void Güncelle_Click(object sender, EventArgs e)
        {
            Güncellle();
        }

        private void Listele_Click(object sender, EventArgs e)
        {
            Listelle(); // Listele metodu çalıştırılır
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Geçerli bir satır seçilmişse
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Seçilen satırdaki veriyi TextBox'lara aktaralım
                txtSiparisUrunID.Text = row.Cells["SiparisUrunID"].Value.ToString();
                txtSiparisID.Text = row.Cells["SiparisID"].Value.ToString();
                txtUrunID.Text = row.Cells["UrunID"].Value.ToString();
                txtMiktar.Text = row.Cells["Miktar"].Value.ToString();
                txtBirimFiyat.Text = row.Cells["BirimFiyat"].Value.ToString();
                txtTutar.Text = row.Cells["Tutar"].Value.ToString();
            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Kullanıcıdan alınan SiparisUrunID'yi alıyoruz
                int siparisUrunIDArama = int.Parse(txtSiparisUrunIDArama.Text); // TextBox'tan alınan SiparisUrunID'yi parse ediyoruz

                using (NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123"))
                {
                    baglanti.Open();  // Bağlantıyı açıyoruz

                    // SiparisUrunID'ye göre sorguyu yazıyoruz
                    string sorgu = "SELECT * FROM SiparisUrun WHERE SiparisUrunID = @p1";
                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                    da.SelectCommand.Parameters.AddWithValue("@p1", siparisUrunIDArama);  // Parametre olarak SiparisUrunID'yi ekliyoruz
                    DataSet ds = new DataSet();
                    da.Fill(ds);  // Veriyi DataSet'e dolduruyoruz

                    // Eğer arama sonucunda veri varsa, DataGridView'e yazdırıyoruz
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        dataGridView1.DataSource = ds.Tables[0];  // Sadece eşleşen veriyi gösteriyoruz
                        MessageBox.Show("Arama başarılı, sipariş ürünü bulundu.");
                    }
                    else
                    {
                        MessageBox.Show("SiparisUrunID ile eşleşen sipariş ürünü bulunamadı.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }
    }
}
