﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace veritabanıproje
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123");
        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123";

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                // GenelKarHesapla fonksiyonunu çağır
                using (var command = new NpgsqlCommand("SELECT GenelKarHesapla();", connection))
                {
                    var result = command.ExecuteScalar(); // Sonucu al

                    // Genel karı dataGridView1'e ekle
                    dataGridView1.Rows.Clear();
                    dataGridView1.Columns.Clear();
                    dataGridView1.Columns.Add("GenelKar", "Genel Kar");
                    dataGridView1.Rows.Add(result); // Sonucu tek satır olarak ekle
                }
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123";

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                // TumMusterilerAktifSiparisler fonksiyonunu çağır
                using (var command = new NpgsqlCommand("SELECT * FROM TumMusterilerAktifSiparisler();", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        // DataGridView'ı temizle
                        dataGridView2.Rows.Clear();
                        dataGridView2.Columns.Clear();

                        // DataGridView için kolonları oluştur
                        dataGridView2.Columns.Add("MusteriID", "Musteri ID");
                        dataGridView2.Columns.Add("AdSoyad", "Ad Soyad");
                        dataGridView2.Columns.Add("SiparisID", "Siparis ID");
                        dataGridView2.Columns.Add("SiparisTarih", "Siparis Tarihi");
                        dataGridView2.Columns.Add("Durum", "Durum");

                        // Verileri DataGridView'a ekle
                        while (reader.Read())
                        {
                            dataGridView2.Rows.Add(reader["MusteriID"], reader["AdSoyad"], reader["SiparisID"], reader["SiparisTarih"], reader["Durum"]);
                        }
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123";

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                // HaftalikSatisRaporu fonksiyonunu çağır
                using (var command = new NpgsqlCommand("SELECT * FROM HaftalikSatisRaporu();", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        // DataGridView'ı temizle
                        dataGridView3.Rows.Clear();
                        dataGridView3.Columns.Clear();

                        // DataGridView için kolonları oluştur
                        dataGridView3.Columns.Add("SiparisID", "Siparis ID");
                        dataGridView3.Columns.Add("MusteriID", "Musteri ID");
                        dataGridView3.Columns.Add("ToplamTutar", "Toplam Tutar");
                        dataGridView3.Columns.Add("SiparisTarih", "Siparis Tarihi");

                        // Verileri DataGridView'a ekle
                        while (reader.Read())
                        {
                            dataGridView3.Rows.Add(reader["SiparisID"], reader["MusteriID"], reader["ToplamTutar"], reader["SiparisTarih"]);
                        }
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost; port=5432; Database=mobilya_satis; user ID=postgres; password=baran123";

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                // PopulerUrunler fonksiyonunu çağır
                using (var command = new NpgsqlCommand("SELECT * FROM PopulerUrunler();", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        // DataGridView'ı temizle
                        dataGridView4.Rows.Clear();
                        dataGridView4.Columns.Clear();

                        // DataGridView için kolonları oluştur
                        dataGridView4.Columns.Add("UrunID", "Urun ID");
                        dataGridView4.Columns.Add("UrunAdi", "Urun Adi");
                        dataGridView4.Columns.Add("ToplamSatis", "Toplam Satis");

                        // Verileri DataGridView'a ekle
                        while (reader.Read())
                        {
                            dataGridView4.Rows.Add(reader["UrunID"], reader["UrunAdi"], reader["ToplamSatis"]);
                        }
                    }
                }
            }
        }
    }
}
